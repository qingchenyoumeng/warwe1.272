<?php
/**
 * ZmqmBuilder —— 私有模型打包器
 *
 * 【功能概述】
 *   解析作品原始ZIP，只保留 MDX/MDL 模型文件 + TEXS块中声明的贴图，
 *   BLP/TGA贴图做 1/2 缩放并转 WebP(q0.7) 压缩，
 *   重新打包为精简的 .zmqm 文件（本质是ZIP格式）。
 *
 * 【BLP贴图格式支持】
 *   - content=0 (JPEG)：
 *     魔兽BLP1的JPEG数据恒为4通道(YCbCrA)，即使头部alphaBits=0。
 *     用_detectJpegChannels()解析SOF0帧头确认实际通道数，4通道一律按
 *     R=255-Cr, G=255-Cb, B=255-Y, A=255 映射（经多模型验证颜色正确）。
 *     注意：第4通道是alpha而非CMYK的K，不可用标准CMYK公式(含(255-K)缩放)，
 *     否则颜色严重偏暗偏蓝。3通道JPEG直接解码。
 *   - content=1 (Palette)：256色调色板(BGRA) + 索引数据 + 可选alpha数据(1/4/8位深)，
 *     用无损WebP编码（有损会导致低alpha区域RGB严重失真）
 *   - DDS：暂不支持，遇到直接抛异常拦截
 *
 * 【MDX TEXS块结构】
 *   每个纹理 268 字节 = ReplaceableId(4) + Image路径(260, \0填充) + Flags(4)
 *   无count字段，数量 = 块size / 268
 *
 * 【用法】
 *   $builder = new ZmqmBuilder();
 *   $result = $builder->build($zipPath, $saveDir, $id, $attId);
 *   // 返回 ['path'=>..., 'filename'=>..., 'stats'=>[...]]
 *
 * 【硬约束】
 *   - 必须安装 php-imagick 扩展，否则直接报错（不允许静默输出BLP/TGA原文件）
 *   - 转换失败一律抛异常，不降级、不回退
 */
class ZmqmBuilder
{
    /**
     * ReplaceableId对应的默认贴图路径（魔兽引擎内置可替换贴图，与前台保持一致）
     * TEXS块中Image为空但ReplaceableId非0时，使用此默认路径
     */
    private static $REPLACEABLE_DEFAULT = [
        11 => 'ReplaceableTextures/TeamColor/TeamGlow1.blp',
        31 => 'ReplaceableTextures/LordaeronTree/LordaeronSummerTree.blp',
        32 => 'ReplaceableTextures/AshenvaleTree/AshenTree.blp',
        33 => 'ReplaceableTextures/BarrensTree/BarrensTree.blp',
        34 => 'ReplaceableTextures/NorthrendTree/NorthrendTree.blp',
        35 => 'ReplaceableTextures/Cityscape/CityscapeTree.blp',
    ];

    /** WebP压缩质量 0.0-1.0 */
    private static $WEBP_QUALITY = 0.7;

    /** 是否将贴图缩放到1/2尺寸（最小64x64不缩放） */
    private static $HALF_SIZE = true;

    /**
     * 打包入口
     *
     * @param string $zipPath  原始作品ZIP路径
     * @param string $saveDir  输出目录
     * @param int    $id       资源ID
     * @param int    $attId    附件ID
     * @return array ['path','filename','stats']
     * @throws \Exception 无Imagick扩展或转换失败时抛出
     */
    public function build($zipPath, $saveDir, $id, $attId)
    {
        // 强制要求Imagick：BLP的4通道JPEG只有Imagick能导出原始CMYK通道值
        if (!class_exists('Imagick')) {
            throw new \Exception('服务器未安装php-imagick扩展，无法转换BLP贴图为WebP。请安装imagick扩展后重试。');
        }
        $fileName = $id . '_' . $attId . '_' . substr(md5(uniqid()), 0, 6) . '.zmqm';
        $outputPath = rtrim($saveDir, '/') . '/' . $fileName;
        $stats = $this->_filterAndRepackZip($zipPath, $outputPath);
        return [
            'path' => $outputPath,
            'filename' => $fileName,
            'stats' => $stats
        ];
    }

    /**
     * 遍历MDX顶层块，对每个块执行回调
     *
     * MDX二进制结构：
     *   头部4字节 'MDLX'
     *   块结构：tag(4) + size(4) + data(size)
     *   第一个块从偏移4开始（不是8）
     *
     * @param string   $mdxBuf   MDX文件二进制内容
     * @param callable $callback 回调 function($tag, $dataOffset, $size)
     */
    private function _forEachBlock($mdxBuf, $callback)
    {
        $len = strlen($mdxBuf);
        if ($len < 8 || substr($mdxBuf, 0, 4) !== 'MDLX') return;
        $offset = 4; // 第一个块从偏移4开始
        while ($offset + 8 <= $len) {
            $tag = substr($mdxBuf, $offset, 4);
            $size = unpack('V', substr($mdxBuf, $offset + 4, 4))[1];
            // size=0的空块（如PREM）跳过，不中断遍历
            if ($size === 0) {
                $offset += 8;
                continue;
            }
            if ($size < 0 || $offset + 8 + $size > $len) break;
            $callback($tag, $offset + 8, $size);
            $offset += 8 + $size;
        }
    }

    /**
     * 解析MDX的TEXS块，返回所有声明的贴图文件名列表
     *
     * TEXS块无count字段，每个纹理固定268字节：
     *   ReplaceableId(4) + Image路径(260字节,\0填充) + Flags(4)
     * Image为空时若ReplaceableId在默认表中则补默认路径
     *
     * @param string $mdxBuf MDX二进制内容
     * @return array 贴图路径列表（已将反斜杠统一为正斜杠）
     */
    private function _extractMdxTextures($mdxBuf)
    {
        $textures = [];
        $this->_forEachBlock($mdxBuf, function($tag, $dataOffset, $size) use (&$textures, $mdxBuf) {
            if ($tag !== 'TEXS') return;
            $count = intdiv($size, 268);
            $texOffset = $dataOffset;
            for ($i = 0; $i < $count; $i++) {
                $repId = unpack('V', substr($mdxBuf, $texOffset, 4))[1];
                $image = rtrim(substr($mdxBuf, $texOffset + 4, 260), "\0");
                if ($image) {
                    $textures[] = str_replace('\\', '/', $image);
                } elseif (isset(self::$REPLACEABLE_DEFAULT[$repId])) {
                    $textures[] = self::$REPLACEABLE_DEFAULT[$repId];
                } else {
                    // 空Image且无默认路径：填null保留索引位置
                    // 否则数组索引与TEXS纹理索引不一致，导致粒子贴图ID映射错误
                    $textures[] = null;
                }
                $texOffset += 268;
            }
        });
        return $textures;
    }

    /**
     * 解析MDX的PRE2块（ParticleEmitter2粒子发射器），返回粒子贴图的TEXS索引集合
     *
     * 【PRE2发射器结构】
     *   emitterSize(4) + nodeSize(4) + name(260) + ObjectId(4) + Parent(4) + Flags(4)
     *   + 可选节点动画块(KGTR/KGRT/KGSC，大小由nodeSize决定)
     *   + Speed(4) + Variation(4) + Latitude(4) + Gravity(4) + LifeSpan(4)
     *   + EmissionRate(4) + Width(4) + Length(4) + FilterMode(4) + Rows(4)
     *   + Columns(4) + frameFlags(4) + TailLength(4) + Time(4)
     *   + SegmentColor(3*3*4=36) + Alpha(3) + ParticleScaling(3*4=12)
     *   + LifeSpanUVAnim(3*4=12) + DecayUVAnim(12) + TailUVAnim(12) + TailDecayUVAnim(12)
     *   + TextureID(4) ← 位置 = emitterStart + 4 + nodeSize + 155
     *
     * 粒子贴图的alpha通道控制粒子形状（光晕/光点），不能强制alpha=255，
     * 需用alpha硬边化(a<128→0, a≥128→255)保留形状。
     *
     * @param string $mdxBuf MDX二进制内容
     * @return array 粒子贴图的TEXS索引集合（int数组）
     */
    private function _extractParticleTextureIds($mdxBuf)
    {
        $ids = [];
        $this->_forEachBlock($mdxBuf, function($tag, $dataOffset, $size) use (&$ids, $mdxBuf) {
            if ($tag !== 'PRE2') return;
            $pos = $dataOffset;
            $end = $dataOffset + $size;
            while ($pos + 8 <= $end) {
                $emitterSize = unpack('V', substr($mdxBuf, $pos, 4))[1];
                if ($emitterSize <= 0 || $emitterSize > 10000) break;
                $nodeSize = unpack('V', substr($mdxBuf, $pos + 4, 4))[1];
                // TextureID位置 = emitterStart + 4 + nodeSize + 155
                $texIdOffset = $pos + 4 + $nodeSize + 155;
                if ($texIdOffset + 4 <= $end) {
                    // 无符号解析后手动转有符号，避免'l'在某些平台行为不一致
                    $texId = unpack('V', substr($mdxBuf, $texIdOffset, 4))[1];
                    if ($texId >= 0x80000000) $texId -= 0x100000000;
                    if ($texId >= 0) {
                        $ids[$texId] = true;
                    }
                }
                $pos += $emitterSize;
            }
        });
        return array_keys($ids);
    }

    /**
     * 原地修改MDX中TEXS块的贴图扩展名：.blp/.tga → .webp
     *
     * 只修改$convertNames中列出的贴图（即真正成功转成WebP的）。
     * 扩展名均为4字符，替换后块大小不变，可直接原地写回。
     *
     * @param string $mdxBuf       MDX二进制内容
     * @param array  $convertNames key=贴图文件名(小写), value=true
     * @return string 修改后的MDX二进制内容
     */
    private function _rewriteMdxTextureExt($mdxBuf, $convertNames)
    {
        $this->_forEachBlock($mdxBuf, function($tag, $dataOffset, $size) use (&$mdxBuf, $convertNames) {
            if ($tag !== 'TEXS') return;
            $count = intdiv($size, 268);
            for ($i = 0; $i < $count; $i++) {
                $texOffset = $dataOffset + $i * 268;
                $repId = unpack('V', substr($mdxBuf, $texOffset, 4))[1];
                $imgOffset = $texOffset + 4;
                $image = rtrim(substr($mdxBuf, $imgOffset, 260), "\0");

                if (!$image) {
                    // Image为空但ReplaceableId在默认表中：写入默认路径的.webp
                    // 否则前台会因Image为空走公共库.blp，而zmqm包里是.webp
                    if (isset(self::$REPLACEABLE_DEFAULT[$repId])) {
                        $defaultPath = self::$REPLACEABLE_DEFAULT[$repId];
                        $baseName = strtolower(basename($defaultPath));
                        if (isset($convertNames[$baseName])) {
                            $newImage = substr($defaultPath, 0, -4) . '.webp';
                            $newImage = str_pad($newImage, 260, "\0");
                            $mdxBuf = substr_replace($mdxBuf, $newImage, $imgOffset, 260);
                        }
                    }
                    continue;
                }

                // basename在Linux上只认正斜杠，MDX路径可能用反斜杠，需先转换
                $baseName = strtolower(basename(str_replace('\\', '/', $image)));
                if (isset($convertNames[$baseName])) {
                    // 替换最后4字符扩展名为.webp，并用\0填充到260字节
                    $newImage = substr($image, 0, -4) . '.webp';
                    $newImage = str_pad($newImage, 260, "\0");
                    $mdxBuf = substr_replace($mdxBuf, $newImage, $imgOffset, 260);
                }
            }
        });
        return $mdxBuf;
    }

    /**
     * 从BLP1(content=0 JPEG格式)中提取完整JPEG数据
     *
     * BLP的JPEG数据分为两部分：
     *   1. 公共JPEG header：偏移160开始，长度由偏移156的headerSize指定
     *   2. 每个mipmap的JPEG数据：偏移由@28的mipOffset表指定
     * 完整JPEG = header + 第一个mipmap的数据
     *
     * @param string $blpData BLP二进制内容
     * @return string|false JPEG数据，非JPEG格式返回false
     */
    private function _extractBlpJpeg($blpData)
    {
        $len = strlen($blpData);
        if ($len < 160 || substr($blpData, 0, 4) !== 'BLP1') return false;
        $content = unpack('V', substr($blpData, 4, 4))[1];
        if ($content !== 0) return false; // 只处理JPEG格式
        $headerSize = unpack('V', substr($blpData, 156, 4))[1];
        if ($headerSize <= 0 || $headerSize > 65536) return false;
        $mipOffset = unpack('V', substr($blpData, 28, 4))[1];
        $mipSize = unpack('V', substr($blpData, 92, 4))[1];
        if ($mipSize <= 0 || $mipOffset + $mipSize > $len) return false;
        return substr($blpData, 160, $headerSize) . substr($blpData, $mipOffset, $mipSize);
    }

    /**
     * 检测JPEG数据的实际通道数（解析SOF0/SOF2标记）
     *
     * 魔兽BLP1的JPEG数据通常是4通道(CMYK)，即使BLP头部alphaBits=0。
     * 不能用alphaBits判断通道数，必须解析JPEG帧头。
     *
     * @param string $jpegData JPEG二进制数据
     * @return int 通道数（3=RGB, 4=CMYK），解析失败返回0
     */
    private function _detectJpegChannels($jpegData)
    {
        $len = strlen($jpegData);
        if ($len < 4 || substr($jpegData, 0, 2) !== "\xFF\xD8") return 0;
        $pos = 2;
        while ($pos + 4 <= $len) {
            if ($jpegData[$pos] !== "\xFF") {
                $pos++;
                continue;
            }
            $marker = ord($jpegData[$pos + 1]);
            // SOF0(0xC0) / SOF1(0xC1) / SOF2(0xC2) 包含通道数
            // SOF0结构: FF C0 + length(2) + precision(1) + height(2) + width(2) + components(1)
            // components在标记开始后第9字节（0-indexed）
            if ($marker >= 0xC0 && $marker <= 0xC2 && $pos + 10 <= $len) {
                return ord($jpegData[$pos + 9]);
            }
            // 跳过标记段
            if ($pos + 4 > $len) break;
            $segLen = unpack('n', substr($jpegData, $pos + 2, 2))[1];
            $pos += 2 + $segLen;
        }
        return 0;
    }

    /**
     * 解码BLP1 palette格式（content=1）为Imagick对象
     *
     * 【文件布局】
     *   偏移156：256色调色板，每色4字节(B,G,R,A)，共1024字节
     *   mipOffset：索引数据，每像素1字节（调色板索引），共width*height字节
     *   mipOffset + width*height：alpha数据（仅当alphaBits>0时存在）
     *
     * 【alpha位深】
     *   alphaBits=8：每像素1字节alpha
     *   alphaBits=4：每像素4位，高半字节=偶数像素，低半字节=奇数像素
     *   alphaBits=1：每像素1位，从字节高位到低位排列
     *   alphaBits=0：无alpha，全部不透明
     *
     * @param string $blpData   BLP二进制内容
     * @param int    $width     图像宽度
     * @param int    $height    图像高度
     * @param int    $alphaBits alpha位深（0/1/4/8）
     * @return \Imagick 解码后的图像对象
     * @throws \Exception 数据不完整时抛出
     */
    private function _decodeBlpPalette($blpData, $width, $height, $alphaBits)
    {
        $len = strlen($blpData);
        if ($len < 156 + 1024) throw new \Exception('BLP palette数据不完整');

        // 第一个mipmap的偏移和大小
        $mipOffset = unpack('V', substr($blpData, 28, 4))[1];
        $mipSize = unpack('V', substr($blpData, 92, 4))[1];
        if ($mipSize <= 0 || $mipOffset + $mipSize > $len) {
            throw new \Exception('BLP palette mipmap数据越界');
        }

        $palette = substr($blpData, 156, 1024);
        $pixelCount = $width * $height;

        // alpha数据紧跟在索引数据之后
        $alphaOffset = $mipOffset + $pixelCount;
        $alphaSize = (int)ceil($pixelCount * $alphaBits / 8);
        $hasAlpha = ($alphaBits > 0 && $alphaOffset + $alphaSize <= $len);

        $rgba = [];
        for ($i = 0; $i < $pixelCount; $i++) {
            // 索引数据：每像素1字节，指向调色板
            $idx = ord($blpData[$mipOffset + $i]);
            $pOff = $idx * 4;
            // 调色板存储顺序为B,G,R,A
            $b = ord($palette[$pOff]);
            $g = ord($palette[$pOff + 1]);
            $r = ord($palette[$pOff + 2]);

            if ($hasAlpha) {
                // 按alpha位深从alpha数据中提取alpha值
                if ($alphaBits === 8) {
                    $rawAlpha = ord($blpData[$alphaOffset + $i]);
                } elseif ($alphaBits === 4) {
                    $byte = ord($blpData[$alphaOffset + (int)($i / 2)]);
                    // 偶数像素用高4位，奇数像素用低4位
                    $rawAlpha = ($i % 2 === 0) ? ($byte >> 4) : ($byte & 0x0F);
                } elseif ($alphaBits === 1) {
                    $byte = ord($blpData[$alphaOffset + (int)($i / 8)]);
                    // 从字节高位(bit7)到低位(bit0)依次排列
                    $rawAlpha = ($byte >> (7 - ($i % 8))) & 1;
                } else {
                    $rawAlpha = 0;
                }
                $maxVal = (1 << $alphaBits) - 1;
                $a = (int)($rawAlpha * 255 / $maxVal);
            } else {
                $a = 255; // 无alpha数据，完全不透明
            }

            $rgba[] = $r;
            $rgba[] = $g;
            $rgba[] = $b;
            $rgba[] = $a;
        }

        // 用Imagick创建RGBA图像
        $imagick = new \Imagick();
        $imagick->newImage($width, $height, 'none');
        $imagick->setImageFormat('png');
        $imagick->importImagePixels(0, 0, $width, $height, 'RGBA', \Imagick::PIXEL_CHAR, $rgba);
        return $imagick;
    }

    /**
     * 将BLP/TGA贴图转换为WebP（1/2缩放，质量0.7）
     *
     * 【转换流程】
     *   1. BLP content=0 JPEG格式：
     *      - 用_detectJpegChannels()解析JPEG帧头获取实际通道数（不能用alphaBits判断，
     *        因为魔兽BLP1的JPEG永远是4通道，alphaBits=0时第4通道无用但仍存在）
     *      - 4通道：Imagick按CMYK解码，导出原始通道后手动映射为RGBA
     *      - 3通道：Imagick直接解码
     *   2. BLP content=1 Palette格式：调用_decodeBlpPalette解码，用无损WebP
     *   3. TGA：Imagick原生支持，直接读取
     *   4. 智能alpha处理（_fixLowAlphaTexture）：低alpha贴图修复WebP预乘损失
     *   5. 缩放至1/2（最小64x64），编码为WebP
     *
     * 【4通道JPEG颜色映射说明】
     *   魔兽BLP的4通道JPEG是YCbCrA格式（JPEG SOF0 component ID=1,2,3,4），
     *   不是标准CMYK。Imagick无APP14标记时默认按CMYK解释，导出顺序[C,M,Y,K]=[Y,Cb,Cr,A]。
     *   正确映射（经齐天大圣/老国王/珊瑚等多模型验证）：
     *     R=255-Cr($cmyk[i+2]), G=255-Cb($cmyk[i+1]), B=255-Y($cmyk[i]), A=255
     *   第4通道是alpha，war3-model解码器同样固定输出alpha=255。
     *   历史bug1：R=255-Y,G=255-M,B=255-C（R/B通道用反）→ 全图偏蓝
     *   历史bug2：标准CMYK公式R=(255-K)-C*(255-K)/255 → 把alpha当K缩放，颜色严重偏暗偏蓝
     *   历史bug3：A=255-K → alpha通道错误，齐天大圣等模型贴图大面积透明
     *   经验证此映射与war3-model前台解码结果完全一致（Diplodocus.blp、老国王模型验证通过）。
     *
     * @param string $texData  贴图文件二进制内容
     * @param string $fileName 贴图文件名（用于错误信息）
     * @return string WebP二进制数据
     * @throws \Exception 转换失败时抛出（不静默回退为原格式）
     */
    private function _convertTextureToWebP($texData, $fileName, $isParticle = false)
    {
        $lower = strtolower($fileName);
        $isBlp = preg_match('/\.blp$/', $lower);
        $isTga = preg_match('/\.tga$/', $lower);
        if (!$isBlp && !$isTga) return $texData;

        $quality = (int)(self::$WEBP_QUALITY * 100);
        $isPaletteBlp = false; // palette格式BLP标记：用无损WebP避免低alpha区域颜色失真

        try {
            $imagick = new \Imagick();
            if ($isBlp) {
                // 读取BLP头部字段
                $content = unpack('V', substr($texData, 4, 4))[1];   // 0=JPEG, 1=palette
                $alphaBits = unpack('V', substr($texData, 8, 4))[1]; // alpha位深
                $width = unpack('V', substr($texData, 12, 4))[1];
                $height = unpack('V', substr($texData, 16, 4))[1];

                if ($content === 0) {
                    // ===== JPEG格式BLP =====
                    // 注意：魔兽BLP1的JPEG数据永远是4通道(CMYK)，即使alphaBits=0
                    // alphaBits=0时第4通道无用但仍存在，直接用Imagick解码会颜色偏蓝
                    $jpegData = $this->_extractBlpJpeg($texData);
                    if ($jpegData === false) {
                        throw new \Exception('BLP JPEG数据提取失败');
                    }

                    // 检测JPEG实际通道数（解析SOF0标记）
                    $jpegChannels = $this->_detectJpegChannels($jpegData);

                    if ($jpegChannels === 4) {
                        // 4通道JPEG：Imagick按CMYK解码，需手动映射为RGBA
                        $imagick->readImageBlob($jpegData);
                        $w = $imagick->getImageWidth();
                        $h = $imagick->getImageHeight();
                        // 导出CMYK四个通道的原始像素值
                        $cmyk = $imagick->exportImagePixels(0, 0, $w, $h, 'CMYK', \Imagick::PIXEL_CHAR);
                        $imagick->destroy();

                        // 魔兽BLP1的4通道JPEG实际为YCbCrA（JPEG SOF0 component id=1,2,3,4），
                        // Imagick无APP14标记时按CMYK解释，导出顺序[C,M,Y,K]=[Y,Cb,Cr,A]。
                        // RGB映射（经node.js运行war3-model解码验证，mean值完全一致）：
                        //   R = 255 - Cr($cmyk[i+2])
                        //   G = 255 - Cb($cmyk[i+1])
                        //   B = 255 - Y ($cmyk[i])
                        //   A = max(1, 255-K)（原始alpha；alpha=0时设为1而非0）
                        // 关键：WebP使用预乘alpha编码，alpha=0时编码器丢弃RGB数据，导致WebP文件
                        // 看起来"丢失内容"。alpha设为1既可保留RGB（WebP不丢弃），前台又几乎完全透明。
                        $count = count($cmyk);
                        $rgba = [];
                        for ($i = 0; $i < $count; $i += 4) {
                            $a = 255 - $cmyk[$i + 3]; // 原始alpha
                            $rgba[] = 255 - $cmyk[$i + 2]; // R ← Cr
                            $rgba[] = 255 - $cmyk[$i + 1]; // G ← Cb
                            $rgba[] = 255 - $cmyk[$i];     // B ← Y亮度
                            $rgba[] = $a === 0 ? 1 : $a;   // A：alpha=0设为1，保留RGB且前台近透明
                        }
                        // 用映射后的RGBA数据创建新图像
                        $imagick = new \Imagick();
                        $imagick->newImage($w, $h, 'none');
                        $imagick->setImageFormat('png');
                        $imagick->importImagePixels(0, 0, $w, $h, 'RGBA', \Imagick::PIXEL_CHAR, $rgba);
                    } else {
                        // 3通道JPEG：Imagick直接解码即可
                        $imagick->readImageBlob($jpegData);
                    }
                } elseif ($content === 1) {
                    // ===== Palette格式BLP =====
                    // 仅256色，有损WebP会严重失真（尤其低alpha区域RGB被压缩算法改变），强制无损编码
                    $isPaletteBlp = true;
                    $imagick->destroy();
                    $imagick = $this->_decodeBlpPalette($texData, $width, $height, $alphaBits);
                } else {
                    throw new \Exception('不支持的BLP内容格式: ' . $content);
                }
            } else {
                // ===== TGA格式：Imagick原生支持 =====
                $imagick->readImageBlob($texData);
            }

            // ===== 智能alpha处理：修复WebP预乘alpha导致低alpha贴图颜色崩坏 =====
            // WebP编码内部使用预乘alpha(RGB'=RGB×α/255)，α很小时RGB被压扁，解压时量化误差被放大几十倍
            // 检测条件：alpha_max<200 且 极淡区(0<a<32)占比>15%
            //   普通贴图：强制alpha=255（Opaque材质本就不用alpha）
            //   粒子贴图：alpha硬边化(a<128→0, a≥128→255)，保留粒子形状
            // 参考：nagaAa022shanhu-7.blp alpha_max=158 极淡区43.7%，WebP后RGB误差56.99→修复后2.82
            $this->_fixLowAlphaTexture($imagick, $isParticle);

            // 1/2缩放（最小64x64，避免图标类贴图过度缩小）
            if (self::$HALF_SIZE) {
                $w = $imagick->getImageWidth();
                $h = $imagick->getImageHeight();
                if ($w > 64 && $h > 64) {
                    $imagick->resizeImage((int)($w / 2), (int)($h / 2), \Imagick::FILTER_LANCZOS, 1);
                }
            }

            // 编码为WebP
            $imagick->setImageFormat('webp');
            if ($isPaletteBlp) {
                // palette格式BLP：无损编码，保留精确RGB值（有损会导致低alpha区域颜色失真）
                $imagick->setOption('webp:lossless', 'true');
            } else {
                $imagick->setImageCompressionQuality($quality);
            }
            $webpData = $imagick->getImageBlob();
            $imagick->destroy();

            if (!$webpData) {
                throw new \Exception('WebP编码输出为空');
            }
            return $webpData;
        } catch (\Exception $e) {
            // 转换失败一律抛异常，绝不静默输出原始BLP/TGA
            throw new \Exception('贴图转WebP失败 [' . $fileName . ']: ' . $e->getMessage());
        }
    }

    /**
     * 智能alpha处理：修复WebP预乘alpha导致低alpha贴图颜色崩坏
     *
     * 【问题根因】
     *   WebP编码内部使用预乘alpha(RGB'=RGB×α/255)，α很小时RGB被压扁到接近0，
     *   解压时unpremultiply的量化误差被放大几十倍，导致低alpha区域出现彩色噪点。
     *
     * 【检测条件】（同时满足才处理）
     *   1. alpha_max < 200（无实心不透明像素）
     *   2. 极淡区(0 < alpha < 32)占比 > 15%
     *
     * 【处理方式】
     *   满足低alpha检测条件时：
     *   - 粒子贴图($isParticle=true)：alpha硬边化(a<128→0, a≥128→255)，保留粒子形状
     *   - 普通贴图($isParticle=false)：强制alpha=255
     *   不满足条件时（如aMax=255的发光粒子）保留原始alpha，避免丢失柔和光晕
     *
     * 【参考数据】
     *   nagaAa022shanhu-7.blp: alpha_max=158, 极淡区43.7%
     *   修复前WebP解码RGB误差=56.99，修复后=2.82
     *
     * @param \Imagick $imagick    已解码的贴图对象（原地修改alpha通道）
     * @param bool     $isParticle 是否为粒子发射器引用的贴图
     * @return void
     */
    private function _fixLowAlphaTexture($imagick, $isParticle = false)
    {
        try {
            $w = $imagick->getImageWidth();
            $h = $imagick->getImageHeight();
            if ($w <= 0 || $h <= 0) return;

            // 导出RGBA像素数据（8位无符号字符）
            $pixels = $imagick->exportImagePixels(0, 0, $w, $h, 'RGBA', \Imagick::PIXEL_CHAR);
            $total = $w * $h;

            $aMax = 0;
            $faint = 0; // 极淡区：0 < alpha < 32
            $nonZero = 0;

            for ($i = 3; $i < count($pixels); $i += 4) {
                $a = $pixels[$i];
                if ($a > $aMax) $aMax = $a;
                if ($a > 0) {
                    $nonZero++;
                    if ($a < 32) $faint++;
                }
            }

            // 检测条件：alpha_max<200 且 极淡区占比>15%
            // 满足条件才处理：粒子贴图硬边化，普通贴图强制不透明
            // 不满足条件（如aMax=255的发光粒子）保留原始alpha，避免丢失柔和光晕
            if ($nonZero > 0 && $aMax < 200 && ($faint / $total) > 0.15) {
                if ($isParticle) {
                    // 粒子贴图：alpha硬边化，保留粒子形状
                    for ($i = 3; $i < count($pixels); $i += 4) {
                        $pixels[$i] = ($pixels[$i] >= 128) ? 255 : 0;
                    }
                } else {
                    // 普通贴图：强制alpha=255
                    for ($i = 3; $i < count($pixels); $i += 4) {
                        $pixels[$i] = 255;
                    }
                }
                $imagick->importImagePixels(0, 0, $w, $h, 'RGBA', \Imagick::PIXEL_CHAR, $pixels);
            }
        } catch (\Exception $e) {
            // alpha处理失败不阻断打包，静默跳过
        }
    }

    /**
     * 贴图筛选重打包主流程
     *
     * 【三步流程】
     *   第一步：扫描ZIP，找到所有MDX/MDL文件，解析TEXS块收集被引用的贴图名；
     *           同时解析PRE2块收集粒子发射器引用的贴图ID（用于alpha硬边化处理）
     *   第二步：预转换所有被引用的BLP/TGA为WebP并缓存；遇到DDS直接报错拦截
     *   第三步：创建新ZIP，写入MDX（改扩展名）+ 转换后的WebP贴图，删除未引用文件和其他杂项
     *
     * 【筛选规则】
     *   - 保留：所有.mdx/.mdl文件 + TEXS块中声明的.blp/.tga/.dds贴图
     *   删除：未被MDX引用的贴图、readme.html、jpg/png等其他所有文件
     *   报错：DDS贴图（暂不支持转换）
     *
     * 【粒子贴图识别】
     *   解析PRE2块（ParticleEmitter2）的TextureID字段，映射到TEXS索引对应的贴图文件名。
     *   粒子贴图的alpha通道控制粒子形状，满足低alpha条件时用硬边化而非强制不透明。
     *   注意：TEXS中空Image纹理（ReplaceableId=1/2等）需填null保留索引，否则ID映射偏移。
     *
     * @param string $zipPath    原始ZIP路径
     * @param string $outputPath 输出.zmqm文件路径
     * @return array 统计信息
     * @throws \Exception 转换失败或ZIP操作失败时抛出
     */
    private function _filterAndRepackZip($zipPath, $outputPath)
    {
        $zipIn = new \ZipArchive();
        if ($zipIn->open($zipPath) !== true) throw new \Exception('无法打开原始ZIP');

        // ===== 第一步：收集MDX引用的贴图 =====
        $mdxFiles = [];
        $allFiles = [];
        for ($i = 0; $i < $zipIn->numFiles; $i++) {
            $name = $zipIn->getNameIndex($i);
            $allFiles[] = $name;
            $lower = strtolower($name);
            if (preg_match('/\.(mdx|mdl)$/', $lower)) {
                $mdxFiles[] = $name;
            }
        }

        // 用文件名（小写）做匹配键，忽略路径前缀
        $refTexNames = [];
        $particleTexNames = []; // 粒子发射器引用的贴图名（alpha需硬边化而非全255）
        foreach ($mdxFiles as $mdxName) {
            $mdxBuf = $zipIn->getFromName($mdxName);
            if ($mdxBuf === false) continue;
            $texs = $this->_extractMdxTextures($mdxBuf);
            foreach ($texs as $t) {
                if ($t === null) continue; // 跳过空Image占位
                $refTexNames[strtolower(basename($t))] = true;
            }
            // 收集粒子贴图ID，映射到TEXS顺序对应的文件名
            $particleIds = $this->_extractParticleTextureIds($mdxBuf);
            foreach ($particleIds as $pid) {
                if (isset($texs[$pid]) && $texs[$pid] !== null) {
                    $particleTexNames[strtolower(basename($texs[$pid]))] = true;
                }
            }
        }

        // ===== 第二步：预转换所有被引用的BLP/TGA =====
        $texCache = [];      // baseName => ['data','outName','converted']
        $convertedNames = []; // 真正转成WebP的贴图名（用于改MDX中的扩展名）
        foreach ($allFiles as $name) {
            $lower = strtolower($name);
            $baseName = strtolower(basename($name));
            if (!isset($refTexNames[$baseName])) continue;

            // DDS暂不支持，直接报错拦截（不允许静默保留DDS）
            if (preg_match('/\.dds$/', $lower)) {
                throw new \Exception('暂不支持DDS贴图转换为WebP: ' . $name . '，请将该贴图转为BLP/TGA格式后重试');
            }
            if (!preg_match('/\.(blp|tga)$/', $lower)) continue;

            $origData = $zipIn->getFromName($name);
            if ($origData === false) continue;

            // 转换失败会抛异常，不会静默输出原始格式
            $isParticle = isset($particleTexNames[$baseName]);
            $newData = $this->_convertTextureToWebP($origData, $name, $isParticle);
            $outName = preg_replace('/\.(blp|tga)$/i', '.webp', $name);
            $convertedNames[$baseName] = true;
            $texCache[$baseName] = ['data' => $newData, 'outName' => $outName, 'converted' => true];
        }

        // ===== 第三步：创建新ZIP并写入 =====
        $zipOut = new \ZipArchive();
        if ($zipOut->open($outputPath, \ZipArchive::CREATE | \ZipArchive::OVERWRITE) !== true) {
            $zipIn->close();
            throw new \Exception('无法创建输出ZIP');
        }

        // 统计变量
        $texTotal = 0;     // 原始ZIP中贴图总数
        $texKept = 0;      // 保留的贴图数
        $texConverted = 0; // 成功转WebP的贴图数
        $texRemoved = 0;   // 被删除的未引用贴图数
        $otherRemoved = 0; // 被删除的其他文件数
        $origSize = 0;     // 原始贴图总大小
        $newSize = 0;      // 转换后贴图总大小

        foreach ($allFiles as $name) {
            $lower = strtolower($name);
            $baseName = strtolower(basename($name));
            if (substr($name, -1) === '/') continue; // 跳过目录条目

            // MDX/MDL文件：保留，并将已转换的贴图扩展名改为.webp
            if (preg_match('/\.(mdx|mdl)$/', $lower)) {
                $mdxBuf = $zipIn->getFromName($name);
                $mdxBuf = $this->_rewriteMdxTextureExt($mdxBuf, $convertedNames);
                $zipOut->addFromString($name, $mdxBuf);
                continue;
            }

            // 贴图文件：仅保留被MDX引用的
            if (preg_match('/\.(blp|tga|dds)$/', $lower)) {
                $texTotal++;
                if (isset($refTexNames[$baseName])) {
                    if (isset($texCache[$baseName])) {
                        // 用预转换的WebP缓存
                        $cached = $texCache[$baseName];
                        $newData = $cached['data'];
                        $outName = $cached['outName'];
                        if ($cached['converted']) $texConverted++;
                    } else {
                        // 理论上不会到这里（DDS已在预转换时报错拦截）
                        $newData = $zipIn->getFromName($name);
                        $outName = $name;
                    }
                    $origSize += strlen($zipIn->getFromName($name));
                    $newSize += strlen($newData);
                    $zipOut->addFromString($outName, $newData);
                    $texKept++;
                } else {
                    $texRemoved++; // 未被引用的贴图，删除
                }
                continue;
            }

            // 其他文件（readme.html、jpg、png等）：一律删除
            $otherRemoved++;
        }

        $zipIn->close();
        $zipOut->close();

        return [
            'mdx' => count($mdxFiles),           // MDX文件数
            'total' => $texTotal,                // 原始贴图总数
            'kept' => $texKept,                  // 保留贴图数
            'converted' => $texConverted,        // 成功转WebP数
            'failed' => $texKept - $texConverted, // 转换失败数（应为0）
            'removed' => $texRemoved,            // 删除的未引用贴图数
            'other_removed' => $otherRemoved,    // 删除的其他文件数
            'orig_tex_size' => $origSize,        // 原始贴图总字节
            'new_tex_size' => $newSize,          // 转换后贴图总字节
            'ratio' => $origSize > 0 ? round($newSize / $origSize, 3) : 1 // 压缩比
        ];
    }
}
